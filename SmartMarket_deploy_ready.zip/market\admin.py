from django.contrib import admin

from .models import Brand, Category, CustomerProfile, Order, OrderItem, Product, Review, StockItem, WholesaleRequest


class StockInline(admin.TabularInline):
    model = StockItem
    extra = 1


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "brand", "price", "wholesale_price", "stock_total", "rating", "is_active")
    list_filter = ("category", "brand", "is_featured", "is_new", "is_sale", "is_active")
    search_fields = ("name", "description", "brand__name")
    prepopulated_fields = {"slug": ("name",)}
    inlines = [StockInline]


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "is_featured")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(Brand)
class BrandAdmin(admin.ModelAdmin):
    search_fields = ("name", "country")


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "customer_name", "status", "is_wholesale", "created_at", "total")
    list_filter = ("status", "is_wholesale", "created_at")
    search_fields = ("customer_name", "email", "phone")
    inlines = [OrderItemInline]


admin.site.register(CustomerProfile)
admin.site.register(Review)
admin.site.register(WholesaleRequest)
