from django.contrib import messages
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import BookingForm
from .models import Booking, Event


def event_list(request):
    event_type = request.GET.get("type", "")
    events = Event.objects.filter(is_active=True, starts_at__gte=timezone.now())
    if event_type:
        events = events.filter(event_type=event_type)

    return render(
        request,
        "bookings/event_list.html",
        {
            "events": events,
            "event_type": event_type,
            "event_types": Event.EVENT_TYPES,
        },
    )


def event_detail(request, pk):
    event = get_object_or_404(Event, pk=pk, is_active=True)
    form = BookingForm(event=event)
    return render(request, "bookings/event_detail.html", {"event": event, "form": form})


@transaction.atomic
def book_event(request, pk):
    event = get_object_or_404(Event.objects.select_for_update(), pk=pk, is_active=True)
    if request.method != "POST":
        return redirect("bookings:event_detail", pk=event.pk)

    form = BookingForm(request.POST, event=event)
    if form.is_valid():
        booking = form.save(commit=False)
        booking.event = event
        booking.status = Booking.Status.CONFIRMED
        booking.save()
        messages.success(request, "Бронювання успішно створено.")
        return redirect("bookings:booking_success", pk=booking.pk)

    return render(request, "bookings/event_detail.html", {"event": event, "form": form})


def booking_success(request, pk):
    booking = get_object_or_404(Booking, pk=pk)
    return render(request, "bookings/booking_success.html", {"booking": booking})
