from django.contrib import admin

from .models import Course, CourseChoice, StudentProfile


class CourseChoiceInline(admin.TabularInline):
    model = CourseChoice
    extra = 0


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ["title", "is_active"]
    list_filter = ["is_active"]
    search_fields = ["title", "description"]


@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ["user", "age", "phone", "email"]
    search_fields = ["user__username", "user__first_name", "user__last_name", "user__email", "phone"]
    inlines = [CourseChoiceInline]

    @admin.display(description="Email")
    def email(self, obj):
        return obj.user.email


@admin.register(CourseChoice)
class CourseChoiceAdmin(admin.ModelAdmin):
    list_display = ["student", "course", "priority"]
    list_filter = ["priority", "course"]
    search_fields = ["student__user__username", "student__user__first_name", "student__user__last_name", "course__title"]
