﻿from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.core.mail import send_mail
from django.db import transaction
from django.shortcuts import redirect, render

from .forms import StudentRegistrationForm
from .models import StudentProfile


class StudentLoginView(LoginView):
    template_name = "students/login.html"
    redirect_authenticated_user = True


@transaction.atomic
def register(request):
    if request.user.is_authenticated:
        return redirect("students:dashboard")

    if request.method == "POST":
        form = StudentRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.first_name = form.cleaned_data["first_name"]
            user.last_name = form.cleaned_data["last_name"]
            user.email = form.cleaned_data["email"]
            user.save()

            StudentProfile.objects.create(
                user=user,
                age=form.cleaned_data["age"],
                phone=form.cleaned_data["phone"],
            )

            send_mail(
                "Реєстрація SmartMarket",
                "Ви успішно зареєструвалися в SmartMarket.",
                "noreply@smartmarket.local",
                [user.email],
                fail_silently=True,
            )
            login(request, user)
            messages.success(request, "Реєстрація успішна. Підтвердження надіслано на email.")
            return redirect("students:dashboard")
    else:
        form = StudentRegistrationForm()

    return render(request, "students/register.html", {"form": form})


@login_required
def dashboard(request):
    return render(request, "students/dashboard.html")


@login_required
def profile(request):
    profile = request.user.student_profile
    return render(request, "students/profile.html", {"profile": profile})
