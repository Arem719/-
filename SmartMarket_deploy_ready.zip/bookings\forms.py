from django import forms

from .models import Booking


class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ["customer_name", "customer_email", "customer_phone", "seats", "notes"]
        widgets = {
            "customer_name": forms.TextInput(attrs={"placeholder": "Ваше ім'я"}),
            "customer_email": forms.EmailInput(attrs={"placeholder": "email@example.com"}),
            "customer_phone": forms.TextInput(attrs={"placeholder": "+380..."}),
            "seats": forms.NumberInput(attrs={"min": 1}),
            "notes": forms.Textarea(attrs={"rows": 3, "placeholder": "Побажання або коментар"}),
        }

    def __init__(self, *args, event=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.event = event
        if event:
            self.fields["seats"].widget.attrs["max"] = event.available_seats

    def clean_seats(self):
        seats = self.cleaned_data["seats"]
        if self.event and seats > self.event.available_seats:
            raise forms.ValidationError("На цю подію вже немає стільки вільних місць.")
        return seats
