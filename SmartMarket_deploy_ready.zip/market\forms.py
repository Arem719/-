﻿from django import forms
from django.core.validators import RegexValidator

from .models import Order, Review, WholesaleRequest


phone_validator = RegexValidator(
    regex=r"^\+380\d{9}$",
    message="Введіть телефон у форматі +380XXXXXXXXX.",
)
name_validator = RegexValidator(
    regex=r"^[A-Za-zА-Яа-яІіЇїЄєҐґ' -]+$",
    message="Поле має містити лише букви.",
)


class ProductFilterForm(forms.Form):
    SORT_CHOICES = [
        ("popular", "Популярні"),
        ("price_asc", "Дешевші"),
        ("price_desc", "Дорожчі"),
        ("rating", "За рейтингом"),
        ("new", "Новинки"),
    ]

    q = forms.CharField(
        required=False,
        label="Пошук",
        widget=forms.TextInput(attrs={"placeholder": "Що шукаєте? Наприклад: смартфон, кава, папір"}),
    )
    category = forms.CharField(required=False)
    brand = forms.CharField(required=False)
    min_price = forms.DecimalField(required=False, min_value=0, label="Ціна від")
    max_price = forms.DecimalField(required=False, min_value=0, label="Ціна до")
    min_rating = forms.DecimalField(required=False, min_value=0, max_value=5, label="Рейтинг від")
    sort = forms.ChoiceField(required=False, choices=SORT_CHOICES, label="Сортування")
    only_sale = forms.BooleanField(required=False, label="Акції")
    only_available = forms.BooleanField(required=False, label="В наявності")

    def clean(self):
        cleaned = super().clean()
        min_price = cleaned.get("min_price")
        max_price = cleaned.get("max_price")
        if min_price is not None and max_price is not None and min_price > max_price:
            raise forms.ValidationError("Мінімальна ціна не може бути більшою за максимальну.")
        return cleaned


class CartAddForm(forms.Form):
    quantity = forms.IntegerField(min_value=1, max_value=999, initial=1, label="Кількість")


class CartUpdateForm(forms.Form):
    quantity = forms.IntegerField(min_value=1, max_value=999, label="Кількість")


class CheckoutForm(forms.ModelForm):
    customer_name = forms.CharField(label="Ім'я та прізвище", validators=[name_validator], max_length=140)
    phone = forms.CharField(label="Телефон", validators=[phone_validator], max_length=13)
    city = forms.CharField(label="Місто", validators=[name_validator], max_length=80)

    class Meta:
        model = Order
        fields = ["customer_name", "email", "phone", "city", "address", "is_wholesale"]
        labels = {
            "email": "Email",
            "address": "Адреса доставки",
            "is_wholesale": "Це оптове замовлення",
        }
        widgets = {"is_wholesale": forms.CheckboxInput()}


class ReviewForm(forms.ModelForm):
    user_name = forms.CharField(label="Ваше ім'я", validators=[name_validator], max_length=120)

    class Meta:
        model = Review
        fields = ["user_name", "rating", "text"]
        labels = {"rating": "Оцінка", "text": "Відгук"}
        widgets = {"text": forms.Textarea(attrs={"rows": 4, "placeholder": "Що сподобалося або що варто покращити?"})}


class WholesaleRequestForm(forms.ModelForm):
    contact_name = forms.CharField(label="Контактна особа", validators=[name_validator], max_length=120)
    phone = forms.CharField(label="Телефон", validators=[phone_validator], max_length=13)

    class Meta:
        model = WholesaleRequest
        fields = ["company_name", "contact_name", "email", "phone", "monthly_budget", "message"]
        labels = {
            "company_name": "Назва компанії",
            "email": "Email",
            "monthly_budget": "Орієнтовний місячний бюджет",
            "message": "Що плануєте закуповувати",
        }
        widgets = {"message": forms.Textarea(attrs={"rows": 4})}
