from django.core.management.base import BaseCommand

from students.models import Course


class Command(BaseCommand):
    help = "Creates demo courses for student registration."

    def handle(self, *args, **options):
        courses = [
            {
                "title": "Python для початківців",
                "description": "Основи Python, змінні, цикли, функції та перші практичні задачі.",
            },
            {
                "title": "Web-розробка з Django",
                "description": "Моделі, форми, шаблони, маршрути й базова адмін-панель Django.",
            },
            {
                "title": "Frontend: HTML, CSS, JavaScript",
                "description": "Створення адаптивних інтерфейсів і інтерактивних сторінок.",
            },
            {
                "title": "Алгоритми та логіка",
                "description": "Практика задач, структур даних і підготовка до технічних олімпіад.",
            },
            {
                "title": "Основи кібербезпеки",
                "description": "Безпечні паролі, веб-ризики, приватність і базові принципи захисту.",
            },
        ]

        for course in courses:
            Course.objects.update_or_create(title=course["title"], defaults=course)

        self.stdout.write(self.style.SUCCESS("Demo courses created."))
