from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone


class Event(models.Model):
    EVENT_TYPES = [
        ("event", "Івент"),
        ("ticket", "Квиток"),
        ("appointment", "Прийом"),
    ]

    title = models.CharField("Назва", max_length=160)
    event_type = models.CharField("Тип", max_length=20, choices=EVENT_TYPES, default="event")
    description = models.TextField("Опис")
    location = models.CharField("Локація", max_length=180, blank=True)
    starts_at = models.DateTimeField("Дата і час")
    price = models.DecimalField("Ціна", max_digits=10, decimal_places=2, default=0)
    capacity = models.PositiveIntegerField("Кількість місць", validators=[MinValueValidator(1)])
    is_active = models.BooleanField("Опубліковано", default=True)
    created_at = models.DateTimeField("Створено", auto_now_add=True)

    class Meta:
        ordering = ["starts_at", "title"]
        verbose_name = "подія"
        verbose_name_plural = "події"

    def __str__(self) -> str:
        return self.title

    @property
    def booked_seats(self) -> int:
        return self.bookings.filter(status=Booking.Status.CONFIRMED).aggregate(
            total=models.Sum("seats")
        )["total"] or 0

    @property
    def available_seats(self) -> int:
        return max(self.capacity - self.booked_seats, 0)

    @property
    def is_upcoming(self) -> bool:
        return self.starts_at >= timezone.now()


class Booking(models.Model):
    class Status(models.TextChoices):
        CONFIRMED = "confirmed", "Підтверджено"
        CANCELLED = "cancelled", "Скасовано"

    event = models.ForeignKey(
        Event,
        verbose_name="Подія",
        related_name="bookings",
        on_delete=models.CASCADE,
    )
    customer_name = models.CharField("Ім'я", max_length=120)
    customer_email = models.EmailField("Email")
    customer_phone = models.CharField("Телефон", max_length=40, blank=True)
    seats = models.PositiveIntegerField("Кількість місць", default=1, validators=[MinValueValidator(1)])
    status = models.CharField(
        "Статус",
        max_length=20,
        choices=Status.choices,
        default=Status.CONFIRMED,
    )
    notes = models.TextField("Коментар", blank=True)
    created_at = models.DateTimeField("Заброньовано", auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "бронювання"
        verbose_name_plural = "бронювання"

    def __str__(self) -> str:
        return f"{self.customer_name} - {self.event.title}"
