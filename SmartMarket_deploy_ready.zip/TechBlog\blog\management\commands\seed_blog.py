from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand

from blog.models import Article, Tag


class Command(BaseCommand):
    help = 'Creates demo data and an admin user for TechBlog.'

    def handle(self, *args, **options):
        User = get_user_model()
        admin_user, _ = User.objects.update_or_create(
            username='admin',
            defaults={
                'email': 'admin@example.com',
                'is_staff': True,
                'is_superuser': True,
            },
        )
        admin_user.set_password('admin12345')
        admin_user.save()

        author, _ = User.objects.update_or_create(
            username='tech_author',
            defaults={'email': 'author@example.com', 'is_staff': True},
        )
        author.set_password('author12345')
        author.save()

        tags_data = [
            ('Django', '#0c7c59'),
            ('Python', '#3776ab'),
            ('DevOps', '#ff7f50'),
            ('AI', '#7b2cbf'),
        ]
        tags = {
            name: Tag.objects.update_or_create(
                name=name,
                defaults={'color': color},
            )[0]
            for name, color in tags_data
        }

        articles_data = [
            {
                'title': 'Як працює Django Admin',
                'content': 'Огляд можливостей адмін-панелі Django для швидкого керування даними.',
                'views': 240,
                'likes': 31,
                'is_featured': True,
                'tags': ['Django', 'Python'],
            },
            {
                'title': 'Основи моделей у Django',
                'content': 'Поля, зв’язки, міграції та практичні поради для структурування даних.',
                'views': 156,
                'likes': 19,
                'is_featured': False,
                'tags': ['Django'],
            },
            {
                'title': 'Автоматизація деплою для блогу',
                'content': 'Як підготувати простий pipeline для публікації Django-проєкту.',
                'views': 98,
                'likes': 12,
                'is_featured': False,
                'tags': ['DevOps', 'Python'],
            },
            {
                'title': 'AI-інструменти для розробників',
                'content': 'Практичні сценарії використання AI в щоденній роботі програміста.',
                'views': 312,
                'likes': 44,
                'is_featured': True,
                'tags': ['AI', 'Python'],
            },
        ]

        for data in articles_data:
            tag_names = data.pop('tags')
            article, _ = Article.objects.update_or_create(
                title=data['title'],
                defaults={**data, 'author': author},
            )
            article.tags.set(tags[name] for name in tag_names)

        self.stdout.write(self.style.SUCCESS('TechBlog demo data created. Admin: admin / admin12345'))
