from decimal import Decimal

from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.urls import reverse


class Category(models.Model):
    name = models.CharField("Назва", max_length=120)
    slug = models.SlugField("URL", unique=True)
    icon = models.CharField("Іконка", max_length=8, blank=True)
    is_featured = models.BooleanField("Популярна", default=False)

    class Meta:
        ordering = ["name"]
        verbose_name = "категорія"
        verbose_name_plural = "категорії"

    def __str__(self) -> str:
        return self.name


class Brand(models.Model):
    name = models.CharField("Назва", max_length=120, unique=True)
    country = models.CharField("Країна", max_length=80, blank=True)

    class Meta:
        ordering = ["name"]
        verbose_name = "бренд"
        verbose_name_plural = "бренди"

    def __str__(self) -> str:
        return self.name


class Product(models.Model):
    category = models.ForeignKey(Category, related_name="products", on_delete=models.PROTECT)
    brand = models.ForeignKey(Brand, related_name="products", on_delete=models.PROTECT)
    name = models.CharField("Назва", max_length=180)
    slug = models.SlugField("URL", unique=True)
    description = models.TextField("Опис")
    price = models.DecimalField("Роздрібна ціна", max_digits=10, decimal_places=2)
    wholesale_price = models.DecimalField("Оптова ціна", max_digits=10, decimal_places=2)
    min_wholesale_quantity = models.PositiveIntegerField("Мінімум для опту", default=10)
    rating = models.DecimalField(
        "Рейтинг",
        max_digits=3,
        decimal_places=1,
        default=4.5,
        validators=[MinValueValidator(Decimal("0")), MaxValueValidator(Decimal("5"))],
    )
    image_color = models.CharField("Колір картки", max_length=24, default="#0f766e")
    is_active = models.BooleanField("Опубліковано", default=True)
    is_featured = models.BooleanField("Популярний", default=False)
    is_new = models.BooleanField("Новинка", default=False)
    is_sale = models.BooleanField("Акція", default=False)
    created_at = models.DateTimeField("Створено", auto_now_add=True)

    class Meta:
        ordering = ["name"]
        verbose_name = "товар"
        verbose_name_plural = "товари"

    def __str__(self) -> str:
        return self.name

    def get_absolute_url(self):
        return reverse("market:product_detail", kwargs={"slug": self.slug})

    @property
    def stock_total(self) -> int:
        return self.stock_items.aggregate(total=models.Sum("quantity"))["total"] or 0

    @property
    def wholesale_discount_percent(self) -> int:
        if not self.price:
            return 0
        discount = (self.price - self.wholesale_price) / self.price * 100
        return max(int(discount), 0)


class StockItem(models.Model):
    product = models.ForeignKey(Product, related_name="stock_items", on_delete=models.CASCADE)
    warehouse = models.CharField("Склад", max_length=120)
    quantity = models.PositiveIntegerField("Залишок", default=0)
    reserved = models.PositiveIntegerField("Заброньовано", default=0)

    class Meta:
        ordering = ["warehouse"]
        verbose_name = "залишок"
        verbose_name_plural = "залишки"

    def __str__(self) -> str:
        return f"{self.product} - {self.warehouse}"

    @property
    def available(self) -> int:
        return max(self.quantity - self.reserved, 0)


class CustomerProfile(models.Model):
    class AccountType(models.TextChoices):
        RETAIL = "retail", "Роздрібний покупець"
        BUSINESS = "business", "Бізнес-акаунт"

    user = models.OneToOneField(settings.AUTH_USER_MODEL, related_name="market_profile", on_delete=models.CASCADE)
    account_type = models.CharField("Тип акаунта", max_length=20, choices=AccountType.choices, default=AccountType.RETAIL)
    company_name = models.CharField("Компанія", max_length=160, blank=True)
    phone = models.CharField("Телефон", max_length=40, blank=True)
    city = models.CharField("Місто", max_length=80, blank=True)

    class Meta:
        verbose_name = "профіль покупця"
        verbose_name_plural = "профілі покупців"

    def __str__(self) -> str:
        return self.company_name or self.user.get_username()


class Order(models.Model):
    class Status(models.TextChoices):
        NEW = "new", "Нове"
        PAID = "paid", "Оплачено"
        PROCESSING = "processing", "Комплектується"
        SHIPPED = "shipped", "Відправлено"
        DONE = "done", "Виконано"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, related_name="market_orders", on_delete=models.SET_NULL)
    customer_name = models.CharField("Покупець", max_length=140)
    email = models.EmailField("Email")
    phone = models.CharField("Телефон", max_length=40)
    city = models.CharField("Місто", max_length=80)
    address = models.CharField("Адреса", max_length=220)
    status = models.CharField("Статус", max_length=20, choices=Status.choices, default=Status.NEW)
    is_wholesale = models.BooleanField("Оптове замовлення", default=False)
    created_at = models.DateTimeField("Створено", auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "замовлення"
        verbose_name_plural = "замовлення"

    def __str__(self) -> str:
        return f"Замовлення #{self.pk or 'new'}"

    @property
    def total(self):
        return sum(item.line_total for item in self.items.all())


class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name="items", on_delete=models.CASCADE)
    product = models.ForeignKey(Product, related_name="order_items", on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField("Кількість", validators=[MinValueValidator(1)])
    price = models.DecimalField("Ціна", max_digits=10, decimal_places=2)

    class Meta:
        verbose_name = "позиція замовлення"
        verbose_name_plural = "позиції замовлень"

    @property
    def line_total(self):
        return self.quantity * self.price


class Review(models.Model):
    product = models.ForeignKey(Product, related_name="reviews", on_delete=models.CASCADE)
    user_name = models.CharField("Ім'я", max_length=120)
    rating = models.PositiveSmallIntegerField("Оцінка", validators=[MinValueValidator(1), MaxValueValidator(5)])
    text = models.TextField("Відгук")
    created_at = models.DateTimeField("Створено", auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "відгук"
        verbose_name_plural = "відгуки"


class WholesaleRequest(models.Model):
    company_name = models.CharField("Компанія", max_length=160)
    contact_name = models.CharField("Контактна особа", max_length=120)
    email = models.EmailField("Email")
    phone = models.CharField("Телефон", max_length=40)
    monthly_budget = models.DecimalField("Місячний бюджет", max_digits=12, decimal_places=2)
    message = models.TextField("Потреби закупівлі")
    created_at = models.DateTimeField("Створено", auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "B2B-заявка"
        verbose_name_plural = "B2B-заявки"

    def __str__(self) -> str:
        return self.company_name
