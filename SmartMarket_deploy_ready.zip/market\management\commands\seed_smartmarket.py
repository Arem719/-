from decimal import Decimal

from django.core.management.base import BaseCommand

from market.models import Brand, Category, Product, Review, StockItem


class Command(BaseCommand):
    help = "Create demo SmartMarket catalog data."

    def handle(self, *args, **options):
        categories = {
            "electronics": ("Електроніка", "💻"),
            "home": ("Дім", "🏠"),
            "food": ("Продукти", "🛒"),
            "beauty": ("Краса", "✦"),
            "office": ("Офіс", "▦"),
            "kids": ("Дитячі товари", "★"),
        }
        category_objects = {}
        for slug, (name, icon) in categories.items():
            category_objects[slug], _ = Category.objects.update_or_create(
                slug=slug,
                defaults={"name": name, "icon": icon, "is_featured": True},
            )

        brand_names = ["NovaTech", "GreenWay", "DailyPro", "FreshLine", "OfficeMax", "Kidora"]
        brands = {name: Brand.objects.get_or_create(name=name, defaults={"country": "Україна"})[0] for name in brand_names}

        products = [
            ("smartfon-novatech-a12", "Смартфон NovaTech A12", "electronics", "NovaTech", "Смартфон з яскравим OLED-дисплеєм, NFC та батареєю на цілий день.", "12999.00", "11199.00", 12, "4.8", "#2563eb", True, True, True),
            ("noutbuk-novatech-pro", "Ноутбук NovaTech Pro 14", "electronics", "NovaTech", "Легкий ноутбук для навчання, роботи та бізнес-команд.", "34999.00", "30999.00", 6, "4.7", "#4338ca", True, False, False),
            ("eco-clean-set", "Набір GreenWay Clean", "home", "GreenWay", "Комплект екологічних засобів для прибирання дому та офісу.", "899.00", "690.00", 20, "4.6", "#16a34a", True, False, True),
            ("dailypro-coffee", "Кава DailyPro Espresso 1 кг", "food", "DailyPro", "Зернова кава для кав'ярень, офісів та домашніх кавомашин.", "649.00", "520.00", 15, "4.9", "#7c2d12", True, True, True),
            ("freshline-vitamins", "Вітамінний набір FreshLine", "beauty", "FreshLine", "Популярний набір для щоденного догляду та підтримки енергії.", "1290.00", "980.00", 10, "4.5", "#db2777", False, True, False),
            ("officemax-paper", "Папір OfficeMax A4, 5 пачок", "office", "OfficeMax", "Офісний папір для щоденного друку з вигідною оптовою ціною.", "1190.00", "940.00", 25, "4.4", "#475569", True, False, True),
            ("kidora-build-set", "Конструктор Kidora City", "kids", "Kidora", "Яскравий конструктор для розвитку логіки та уяви.", "1599.00", "1299.00", 8, "4.8", "#f59e0b", True, True, False),
            ("greenway-towels", "Рушники GreenWay Hotel, 12 шт.", "home", "GreenWay", "М'які рушники для готелів, салонів і домашнього використання.", "2190.00", "1750.00", 10, "4.6", "#0d9488", False, False, True),
        ]

        for slug, name, category_slug, brand_name, description, price, wholesale_price, min_qty, rating, color, featured, is_new, sale in products:
            product, _ = Product.objects.update_or_create(
                slug=slug,
                defaults={
                    "name": name,
                    "category": category_objects[category_slug],
                    "brand": brands[brand_name],
                    "description": description,
                    "price": Decimal(price),
                    "wholesale_price": Decimal(wholesale_price),
                    "min_wholesale_quantity": min_qty,
                    "rating": Decimal(rating),
                    "image_color": color,
                    "is_featured": featured,
                    "is_new": is_new,
                    "is_sale": sale,
                    "is_active": True,
                },
            )
            StockItem.objects.update_or_create(product=product, warehouse="Київ", defaults={"quantity": 120 + min_qty, "reserved": 8})
            StockItem.objects.update_or_create(product=product, warehouse="Львів", defaults={"quantity": 60 + min_qty, "reserved": 3})
            Review.objects.get_or_create(
                product=product,
                user_name="Олена",
                defaults={"rating": 5, "text": "Швидка доставка, зрозумілий опис і хороша ціна для повторної покупки."},
            )

        self.stdout.write(self.style.SUCCESS("SmartMarket demo catalog created."))
