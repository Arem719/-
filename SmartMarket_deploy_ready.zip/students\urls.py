from django.contrib.auth.views import LogoutView
from django.urls import path

from . import views


app_name = "students"

urlpatterns = [
    path("register/", views.register, name="register"),
    path("login/", views.StudentLoginView.as_view(), name="login"),
    path("logout/", LogoutView.as_view(), name="logout"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("profile/", views.profile, name="profile"),
]
