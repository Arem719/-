﻿from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.forms import formset_factory

from .models import Course, CourseChoice, phone_validator


def validate_human_name(value):
    cleaned = value.strip()
    allowed_extra = {"'", "’", "-", " "}
    if not cleaned or not all(ch.isalpha() or ch in allowed_extra for ch in cleaned):
        raise ValidationError("Введіть ім'я буквами, без цифр і спеціальних символів.")


def normalize_ua_phone(value):
    phone = value.strip().replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
    if phone.startswith("0") and len(phone) == 10:
        phone = "+38" + phone
    elif phone.startswith("380") and len(phone) == 12:
        phone = "+" + phone
    return phone


class StudentRegistrationForm(UserCreationForm):
    first_name = forms.CharField(
        label="Ім'я",
        max_length=150,
        validators=[validate_human_name],
        widget=forms.TextInput(attrs={"placeholder": "Наприклад: Іван"}),
    )
    last_name = forms.CharField(
        label="Прізвище",
        max_length=150,
        validators=[validate_human_name],
        widget=forms.TextInput(attrs={"placeholder": "Наприклад: Петренко"}),
    )
    email = forms.EmailField(label="Email", widget=forms.EmailInput(attrs={"placeholder": "name@example.com"}))
    age = forms.IntegerField(label="Вік", min_value=14, max_value=100)
    phone = forms.CharField(label="Телефон", max_length=18, widget=forms.TextInput(attrs={"placeholder": "+380991112233 або 0991112233"}))
    password1 = forms.CharField(label="Пароль", widget=forms.PasswordInput)
    password2 = forms.CharField(label="Підтвердження пароля", widget=forms.PasswordInput)

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ["username", "first_name", "last_name", "email", "age", "phone", "password1", "password2"]
        labels = {"username": "Ім'я користувача"}
        widgets = {"username": forms.TextInput(attrs={"placeholder": "Логін для входу"})}

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("Користувач з таким email вже існує.")
        return email

    def clean_first_name(self):
        return self.cleaned_data["first_name"].strip().title()

    def clean_last_name(self):
        return self.cleaned_data["last_name"].strip().title()

    def clean_phone(self):
        phone = normalize_ua_phone(self.cleaned_data["phone"])
        phone_validator(phone)
        return phone


class CourseChoiceForm(forms.Form):
    course = forms.ModelChoiceField(label="Курс", queryset=Course.objects.none(), empty_label="Оберіть курс")
    priority = forms.ChoiceField(label="Пріоритет", choices=CourseChoice.Priority.choices)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["course"].queryset = Course.objects.filter(is_active=True)


BaseCourseChoiceFormSet = formset_factory(CourseChoiceForm, extra=3, max_num=3, validate_max=True)


class CourseChoiceFormSet(BaseCourseChoiceFormSet):
    def clean(self):
        super().clean()
        if any(self.errors):
            return

        courses = []
        priorities = []
        for form in self.forms:
            course = form.cleaned_data.get("course")
            priority = form.cleaned_data.get("priority")
            if course:
                courses.append(course.pk)
            if priority:
                priorities.append(priority)

        if len(courses) != 3 or len(priorities) != 3:
            raise forms.ValidationError("Оберіть три курси та вкажіть пріоритети 1, 2, 3.")
        if len(courses) != len(set(courses)):
            raise forms.ValidationError("Курси не можуть повторюватися.")
        if len(priorities) != len(set(priorities)):
            raise forms.ValidationError("Пріоритети мають бути унікальними.")
        if set(priorities) != {"1", "2", "3"}:
            raise forms.ValidationError("Використайте пріоритети 1, 2 і 3.")
