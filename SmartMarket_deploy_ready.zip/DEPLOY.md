﻿# SmartMarket: інструкція для деплою

Проєкт уже підготовлений для публічного запуску Django-сайту на Render, Railway, VPS або Docker-хостингу.

## Найпростіший варіант: Render

1. Завантаж весь проєкт на GitHub.
2. На Render створи `New Web Service` з цього репозиторію.
3. Налаштування:
   - Runtime: `Python`
   - Build command: `pip install -r requirements.txt && python manage.py collectstatic --noinput`
   - Start command: `gunicorn booking_platform.wsgi:application --bind 0.0.0.0:$PORT`
4. Environment variables:
   - `DEBUG=0`
   - `SECRET_KEY=` довгий випадковий секретний ключ
   - `ALLOWED_HOSTS=твій-домен.onrender.com`
   - `CSRF_TRUSTED_ORIGINS=https://твій-домен.onrender.com`
   - `DATABASE_URL=` URL PostgreSQL, якщо підключаєш базу Render/Railway
   - `SECURE_SSL_REDIRECT=0` для Render можна лишити 0, бо HTTPS робить сама платформа
5. Після першого деплою в Render Shell виконай:
   - `python manage.py migrate`
   - `python manage.py seed_smartmarket`
   - `python manage.py createsuperuser`

## Docker або VPS

```bash
docker compose up --build -d
docker compose exec web python manage.py createsuperuser
```

## Файли для хостингу

- `requirements.txt` - залежності Django, Gunicorn, WhiteNoise, PostgreSQL support.
- `Procfile` - команди для платформ типу Heroku/Railway.
- `render.yaml` - шаблон Render Blueprint.
- `Dockerfile` - контейнер для VPS або Docker-хостингу.
- `.env.example` - приклад змінних середовища.

## Перевірка перед деплоєм

```bash
python manage.py check
python manage.py check --deploy
python manage.py migrate --check
python manage.py collectstatic --noinput
```

## Адмін-панель

Після створення суперкористувача відкрий:

`https://твій-домен/admin/`

## Важливо про базу даних

Для справжнього сайту краще PostgreSQL через `DATABASE_URL`.
Якщо `DATABASE_URL` не заданий, сайт використовує SQLite у папці `data/`.
