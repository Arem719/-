from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand

from library.models import Author, Book, Loan, Reader


class Command(BaseCommand):
    help = 'Creates demo data and an admin user for the library system.'

    def handle(self, *args, **options):
        User = get_user_model()
        User.objects.update_or_create(
            username='admin',
            defaults={
                'email': 'admin@example.com',
                'is_staff': True,
                'is_superuser': True,
            },
        )
        admin_user = User.objects.get(username='admin')
        admin_user.set_password('admin12345')
        admin_user.save()

        authors_data = [
            {'name': 'Ліна Костенко', 'country': 'Україна', 'birth_year': 1930},
            {'name': 'Джордж Орвелл', 'country': 'Велика Британія', 'birth_year': 1903},
            {'name': 'Харукі Муракамі', 'country': 'Японія', 'birth_year': 1949},
        ]
        authors = {
            data['name']: Author.objects.update_or_create(
                name=data['name'],
                defaults=data,
            )[0]
            for data in authors_data
        }

        books_data = [
            {
                'title': 'Маруся Чурай',
                'author': authors['Ліна Костенко'],
                'isbn': '9786175850011',
                'pages': 224,
                'publication_year': 1979,
                'is_available': False,
            },
            {
                'title': 'Записки українського самашедшого',
                'author': authors['Ліна Костенко'],
                'isbn': '9789661410412',
                'pages': 416,
                'publication_year': 2010,
                'is_available': True,
            },
            {
                'title': '1984',
                'author': authors['Джордж Орвелл'],
                'isbn': '9780451524935',
                'pages': 328,
                'publication_year': 1949,
                'is_available': False,
            },
            {
                'title': 'Колгосп тварин',
                'author': authors['Джордж Орвелл'],
                'isbn': '9780141036137',
                'pages': 112,
                'publication_year': 1945,
                'is_available': True,
            },
            {
                'title': 'Норвезький ліс',
                'author': authors['Харукі Муракамі'],
                'isbn': '9780375704024',
                'pages': 296,
                'publication_year': 1987,
                'is_available': False,
            },
        ]
        books = {
            data['title']: Book.objects.update_or_create(
                isbn=data['isbn'],
                defaults=data,
            )[0]
            for data in books_data
        }

        readers_data = [
            {'name': 'Олена Петренко', 'email': 'olena@example.com'},
            {'name': 'Андрій Шевченко', 'email': 'andrii@example.com'},
            {'name': 'Марія Коваленко', 'email': 'maria@example.com'},
        ]
        readers = {
            data['name']: Reader.objects.update_or_create(
                email=data['email'],
                defaults=data,
            )[0]
            for data in readers_data
        }

        loans_data = [
            (readers['Олена Петренко'], books['Маруся Чурай']),
            (readers['Олена Петренко'], books['1984']),
            (readers['Андрій Шевченко'], books['Норвезький ліс']),
            (readers['Марія Коваленко'], books['Колгосп тварин']),
        ]
        for reader, book in loans_data:
            Loan.objects.get_or_create(reader=reader, book=book)

        self.stdout.write(self.style.SUCCESS('Library demo data created. Admin: admin / admin12345'))
