from django.contrib import admin
from django.http import HttpResponse
import csv

from .models import Article, Tag


@admin.action(description='Позначити обрані статті як featured')
def mark_as_featured(modeladmin, request, queryset):
    queryset.update(is_featured=True)


@admin.action(description='Скинути лічильник переглядів')
def reset_views(modeladmin, request, queryset):
    queryset.update(views=0)


@admin.action(description='Експортувати обрані статті в CSV')
def export_articles(modeladmin, request, queryset):
    response = HttpResponse(content_type='text/csv; charset=utf-8')
    response['Content-Disposition'] = 'attachment; filename="articles.csv"'
    response.write('\ufeff')

    writer = csv.writer(response)
    writer.writerow(['Title', 'Author', 'Views', 'Likes', 'Featured', 'Published at', 'Tags'])

    for article in queryset.select_related('author').prefetch_related('tags'):
        writer.writerow([
            article.title,
            article.author.username,
            article.views,
            article.likes,
            article.is_featured,
            article.published_at,
            ', '.join(tag.name for tag in article.tags.all()),
        ])

    return response


@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ['name', 'color']
    search_fields = ['name']


@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    list_display = ['title', 'author', 'views', 'likes', 'is_featured', 'published_at']
    list_filter = ['is_featured', 'published_at', 'author', 'tags']
    search_fields = ['title', 'content']
    list_editable = ['is_featured']
    filter_horizontal = ['tags']
    readonly_fields = ['views', 'likes']
    actions = [mark_as_featured, reset_views, export_articles]
