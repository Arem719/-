﻿from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator, MinValueValidator, RegexValidator


phone_validator = RegexValidator(
    regex=r"^\+380\d{9}$",
    message="Телефон має бути у форматі +380XXXXXXXXX.",
)


class Course(models.Model):
    title = models.CharField("Назва курсу", max_length=160)
    description = models.TextField("Опис", blank=True)
    is_active = models.BooleanField("Активний", default=True)

    class Meta:
        ordering = ["title"]
        verbose_name = "курс"
        verbose_name_plural = "курси"

    def __str__(self):
        return self.title


class StudentProfile(models.Model):
    user = models.OneToOneField(
        User,
        verbose_name="Користувач",
        related_name="student_profile",
        on_delete=models.CASCADE,
    )
    age = models.PositiveSmallIntegerField(
        "Вік",
        validators=[MinValueValidator(14), MaxValueValidator(100)],
    )
    phone = models.CharField("Телефон", max_length=13, validators=[phone_validator])

    class Meta:
        ordering = ["user__last_name", "user__first_name"]
        verbose_name = "профіль користувача"
        verbose_name_plural = "профілі користувачів"

    def __str__(self):
        return self.user.get_full_name() or self.user.username


class CourseChoice(models.Model):
    class Priority(models.IntegerChoices):
        FIRST = 1, "1"
        SECOND = 2, "2"
        THIRD = 3, "3"

    student = models.ForeignKey(
        StudentProfile,
        verbose_name="Користувач",
        related_name="course_choices",
        on_delete=models.CASCADE,
    )
    course = models.ForeignKey(
        Course,
        verbose_name="Курс",
        related_name="student_choices",
        on_delete=models.CASCADE,
    )
    priority = models.PositiveSmallIntegerField(
        "Пріоритет",
        choices=Priority.choices,
        validators=[MinValueValidator(1), MaxValueValidator(3)],
    )

    class Meta:
        ordering = ["priority"]
        constraints = [
            models.UniqueConstraint(fields=["student", "course"], name="unique_course_per_student"),
            models.UniqueConstraint(fields=["student", "priority"], name="unique_priority_per_student"),
        ]
        verbose_name = "вибір курсу"
        verbose_name_plural = "вибір курсів"

    def __str__(self):
        return f"{self.student} - {self.course} ({self.priority})"
