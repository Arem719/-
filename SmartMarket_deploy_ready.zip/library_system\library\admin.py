from django.contrib import admin

from .models import Author, Book, Loan, Reader


@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ['name', 'country', 'birth_year']
    search_fields = ['name', 'country']


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ['title', 'author', 'isbn', 'pages', 'publication_year', 'is_available']
    list_filter = ['is_available', 'publication_year', 'author']
    search_fields = ['title', 'author__name', 'isbn']
    list_editable = ['is_available']


@admin.register(Reader)
class ReaderAdmin(admin.ModelAdmin):
    list_display = ['name', 'email']
    search_fields = ['name', 'email']


@admin.register(Loan)
class LoanAdmin(admin.ModelAdmin):
    list_display = ['reader', 'book', 'loan_date', 'return_date']
    list_filter = ['loan_date', 'return_date', 'book__author']
    search_fields = ['reader__name', 'book__title']
