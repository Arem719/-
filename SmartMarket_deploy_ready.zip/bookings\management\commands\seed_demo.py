from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from bookings.models import Event


class Command(BaseCommand):
    help = "Create demo events for the booking platform"

    def handle(self, *args, **options):
        items = [
            {
                "title": "UX Meetup Kyiv",
                "event_type": "event",
                "description": "Вечір практичних доповідей про дизайн сервісів, дослідження користувачів і продуктові рішення.",
                "location": "Київ, Creative State Arsenal",
                "starts_at": timezone.now() + timedelta(days=5, hours=2),
                "price": 450,
                "capacity": 80,
            },
            {
                "title": "Квиток на камерний концерт",
                "event_type": "ticket",
                "description": "Живий акустичний сет у невеликій залі з обмеженою кількістю місць.",
                "location": "Львів, зал камерної музики",
                "starts_at": timezone.now() + timedelta(days=9, hours=4),
                "price": 700,
                "capacity": 45,
            },
            {
                "title": "Консультація кар'єрного ментора",
                "event_type": "appointment",
                "description": "Індивідуальний запис на прийом: розбір резюме, план розвитку та підготовка до співбесіди.",
                "location": "Онлайн",
                "starts_at": timezone.now() + timedelta(days=3, hours=1),
                "price": 1200,
                "capacity": 6,
            },
        ]

        created = 0
        for item in items:
            _, was_created = Event.objects.get_or_create(title=item["title"], defaults=item)
            created += int(was_created)

        self.stdout.write(self.style.SUCCESS(f"Demo events ready. Created: {created}"))
