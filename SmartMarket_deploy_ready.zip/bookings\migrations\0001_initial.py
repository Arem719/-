from django.db import migrations, models
import django.core.validators
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Event",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(max_length=160, verbose_name="Назва")),
                (
                    "event_type",
                    models.CharField(
                        choices=[("event", "Івент"), ("ticket", "Квиток"), ("appointment", "Прийом")],
                        default="event",
                        max_length=20,
                        verbose_name="Тип",
                    ),
                ),
                ("description", models.TextField(verbose_name="Опис")),
                ("location", models.CharField(blank=True, max_length=180, verbose_name="Локація")),
                ("starts_at", models.DateTimeField(verbose_name="Дата і час")),
                ("price", models.DecimalField(decimal_places=2, default=0, max_digits=10, verbose_name="Ціна")),
                (
                    "capacity",
                    models.PositiveIntegerField(
                        validators=[django.core.validators.MinValueValidator(1)],
                        verbose_name="Кількість місць",
                    ),
                ),
                ("is_active", models.BooleanField(default=True, verbose_name="Опубліковано")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Створено")),
            ],
            options={
                "verbose_name": "подія",
                "verbose_name_plural": "події",
                "ordering": ["starts_at", "title"],
            },
        ),
        migrations.CreateModel(
            name="Booking",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("customer_name", models.CharField(max_length=120, verbose_name="Ім'я")),
                ("customer_email", models.EmailField(max_length=254, verbose_name="Email")),
                ("customer_phone", models.CharField(blank=True, max_length=40, verbose_name="Телефон")),
                (
                    "seats",
                    models.PositiveIntegerField(
                        default=1,
                        validators=[django.core.validators.MinValueValidator(1)],
                        verbose_name="Кількість місць",
                    ),
                ),
                (
                    "status",
                    models.CharField(
                        choices=[("confirmed", "Підтверджено"), ("cancelled", "Скасовано")],
                        default="confirmed",
                        max_length=20,
                        verbose_name="Статус",
                    ),
                ),
                ("notes", models.TextField(blank=True, verbose_name="Коментар")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Заброньовано")),
                (
                    "event",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="bookings",
                        to="bookings.event",
                        verbose_name="Подія",
                    ),
                ),
            ],
            options={
                "verbose_name": "бронювання",
                "verbose_name_plural": "бронювання",
                "ordering": ["-created_at"],
            },
        ),
    ]
