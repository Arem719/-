from django.urls import path

from . import views


app_name = "bookings"

urlpatterns = [
    path("", views.event_list, name="event_list"),
    path("events/<int:pk>/", views.event_detail, name="event_detail"),
    path("events/<int:pk>/book/", views.book_event, name="book_event"),
    path("booking/<int:pk>/success/", views.booking_success, name="booking_success"),
]
