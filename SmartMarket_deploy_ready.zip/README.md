# BookNest

Django-веб-додаток для бронювання квитків, подій і записів на прийом.

## Можливості

- публічний список доступних подій;
- фільтр за типом: івент, квиток, прийом;
- сторінка деталей події;
- бронювання одного або кількох місць;
- перевірка доступної кількості місць;
- керування подіями й бронюваннями через Django Admin;
- запуск у Docker.

## Запуск через Docker

```bash
docker compose up --build
```

Після старту відкрийте `http://localhost:8000`.

## Створення адміністратора

В окремому терміналі:

```bash
docker compose exec web python manage.py createsuperuser
```

Адмінка доступна за адресою `http://localhost:8000/admin/`.

## Локальний запуск без Docker

```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo
python manage.py runserver
```
