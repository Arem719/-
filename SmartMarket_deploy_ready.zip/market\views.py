﻿from decimal import Decimal

from django.contrib import messages
from django.db.models import Count, Q, Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import CartAddForm, CartUpdateForm, CheckoutForm, ProductFilterForm, ReviewForm, WholesaleRequestForm
from .models import Brand, Category, OrderItem, Product


SORT_MAP = {
    "price_asc": "price",
    "price_desc": "-price",
    "rating": "-rating",
    "new": "-created_at",
    "popular": "-is_featured",
}


def _cart(session):
    return session.setdefault("smartmarket_cart", {})


def _wishlist(session):
    return session.setdefault("smartmarket_wishlist", [])


def _compare(session):
    return session.setdefault("smartmarket_compare", [])


def _viewed(session):
    return session.setdefault("smartmarket_viewed", [])


def _cart_items(session):
    cart = _cart(session)
    products = Product.objects.filter(id__in=cart.keys()).select_related("category", "brand").prefetch_related("stock_items")
    items = []
    total = Decimal("0")
    for product in products:
        quantity = int(cart[str(product.id)])
        unit_price = product.wholesale_price if quantity >= product.min_wholesale_quantity else product.price
        line_total = unit_price * quantity
        total += line_total
        items.append({"product": product, "quantity": quantity, "unit_price": unit_price, "line_total": line_total})
    return items, total


def _market_context(request):
    return {
        "cart_count": sum(int(qty) for qty in _cart(request.session).values()),
        "wishlist_count": len(_wishlist(request.session)),
        "compare_count": len(_compare(request.session)),
    }


def home(request):
    featured = Product.objects.filter(is_active=True, is_featured=True).select_related("category", "brand")[:8]
    new_products = Product.objects.filter(is_active=True, is_new=True).select_related("category", "brand")[:4]
    sale_products = Product.objects.filter(is_active=True, is_sale=True).select_related("category", "brand")[:4]
    categories = Category.objects.filter(is_featured=True).annotate(product_count=Count("products"))[:8]
    viewed_products = Product.objects.filter(id__in=_viewed(request.session), is_active=True).select_related("category", "brand")[:4]
    context = {
        "featured": featured,
        "new_products": new_products,
        "sale_products": sale_products,
        "categories": categories,
        "viewed_products": viewed_products,
    }
    context.update(_market_context(request))
    return render(request, "market/home.html", context)


def catalog(request):
    form = ProductFilterForm(request.GET)
    products = Product.objects.filter(is_active=True).select_related("category", "brand").prefetch_related("stock_items")
    active_filters = []
    if form.is_valid():
        data = form.cleaned_data
        if data.get("q"):
            query = data["q"].strip()
            products = products.filter(Q(name__icontains=query) | Q(description__icontains=query) | Q(brand__name__icontains=query) | Q(category__name__icontains=query))
            active_filters.append(f"Пошук: {query}")
        if data.get("category"):
            products = products.filter(category__slug=data["category"])
            active_filters.append("Категорія")
        if data.get("brand"):
            products = products.filter(brand__name=data["brand"])
            active_filters.append(f"Бренд: {data['brand']}")
        if data.get("min_price") is not None:
            products = products.filter(price__gte=data["min_price"])
            active_filters.append(f"від {data['min_price']} грн")
        if data.get("max_price") is not None:
            products = products.filter(price__lte=data["max_price"])
            active_filters.append(f"до {data['max_price']} грн")
        if data.get("min_rating") is not None:
            products = products.filter(rating__gte=data["min_rating"])
            active_filters.append(f"рейтинг від {data['min_rating']}")
        if data.get("only_sale"):
            products = products.filter(is_sale=True)
            active_filters.append("Акції")
        if data.get("only_available"):
            products = products.annotate(stock_sum=Sum("stock_items__quantity")).filter(stock_sum__gt=0)
            active_filters.append("В наявності")
        products = products.order_by(SORT_MAP.get(data.get("sort") or "popular", "-is_featured"), "name")
    else:
        products = products.order_by("-is_featured", "name")

    context = {
        "form": form,
        "products": products,
        "result_count": products.count(),
        "categories": Category.objects.annotate(product_count=Count("products")),
        "brands": Brand.objects.all(),
        "wishlist": _wishlist(request.session),
        "compare": _compare(request.session),
        "active_filters": active_filters,
    }
    context.update(_market_context(request))
    return render(request, "market/catalog.html", context)


def product_detail(request, slug):
    product = get_object_or_404(Product.objects.select_related("category", "brand").prefetch_related("stock_items", "reviews"), slug=slug, is_active=True)
    viewed = _viewed(request.session)
    if product.id in viewed:
        viewed.remove(product.id)
    viewed.insert(0, product.id)
    del viewed[8:]
    request.session.modified = True

    review_form = ReviewForm()
    if request.method == "POST":
        review_form = ReviewForm(request.POST)
        if review_form.is_valid():
            review = review_form.save(commit=False)
            review.product = product
            review.save()
            messages.success(request, "Дякуємо, відгук додано.")
            return redirect(product)
    similar = Product.objects.filter(category=product.category, is_active=True).exclude(pk=product.pk).select_related("category", "brand")[:4]
    context = {
        "product": product,
        "cart_form": CartAddForm(),
        "review_form": review_form,
        "similar": similar,
        "in_wishlist": product.id in _wishlist(request.session),
        "in_compare": product.id in _compare(request.session),
    }
    context.update(_market_context(request))
    return render(request, "market/product_detail.html", context)


@require_POST
def cart_add(request, product_id):
    product = get_object_or_404(Product, pk=product_id, is_active=True)
    form = CartAddForm(request.POST)
    if form.is_valid():
        cart = _cart(request.session)
        key = str(product.id)
        cart[key] = int(cart.get(key, 0)) + form.cleaned_data["quantity"]
        request.session.modified = True
        messages.success(request, "Товар додано до кошика.")
    else:
        messages.error(request, "Вкажіть коректну кількість.")
    return redirect(request.POST.get("next") or product)


@require_POST
def cart_update(request, product_id):
    product = get_object_or_404(Product, pk=product_id, is_active=True)
    form = CartUpdateForm(request.POST)
    if form.is_valid():
        cart = _cart(request.session)
        cart[str(product.id)] = form.cleaned_data["quantity"]
        request.session.modified = True
        messages.success(request, "Кількість оновлено.")
    else:
        messages.error(request, "Вкажіть кількість від 1 до 999.")
    return redirect("market:cart")


def cart_remove(request, product_id):
    cart = _cart(request.session)
    cart.pop(str(product_id), None)
    request.session.modified = True
    messages.info(request, "Товар прибрано з кошика.")
    return redirect("market:cart")


def cart_clear(request):
    request.session["smartmarket_cart"] = {}
    messages.info(request, "Кошик очищено.")
    return redirect("market:cart")


def cart_detail(request):
    items, total = _cart_items(request.session)
    context = {"items": items, "total": total}
    context.update(_market_context(request))
    return render(request, "market/cart.html", context)


def wishlist_toggle(request, product_id):
    product = get_object_or_404(Product, pk=product_id, is_active=True)
    wishlist = _wishlist(request.session)
    if product.id in wishlist:
        wishlist.remove(product.id)
        messages.info(request, "Товар прибрано з обраного.")
    else:
        wishlist.append(product.id)
        messages.success(request, "Товар додано в обране.")
    request.session.modified = True
    return redirect(request.GET.get("next") or "market:catalog")


def compare_add(request, product_id):
    product = get_object_or_404(Product, pk=product_id, is_active=True)
    compare = _compare(request.session)
    if product.id not in compare:
        if len(compare) >= 4:
            messages.warning(request, "Для порівняння можна додати до 4 товарів.")
        else:
            compare.append(product.id)
            messages.success(request, "Товар додано до порівняння.")
    request.session.modified = True
    return redirect(request.GET.get("next") or "market:catalog")


def compare_remove(request, product_id):
    compare = _compare(request.session)
    if product_id in compare:
        compare.remove(product_id)
        request.session.modified = True
    return redirect("market:compare")


def compare_detail(request):
    products = Product.objects.filter(id__in=_compare(request.session), is_active=True).select_related("category", "brand").prefetch_related("stock_items")
    context = {"products": products}
    context.update(_market_context(request))
    return render(request, "market/compare.html", context)


def checkout(request):
    items, total = _cart_items(request.session)
    if not items:
        messages.info(request, "Додайте товари в кошик перед оформленням.")
        return redirect("market:cart")
    form = CheckoutForm(request.POST or None)
    if form.is_valid():
        order = form.save(commit=False)
        if request.user.is_authenticated:
            order.user = request.user
        order.save()
        for item in items:
            OrderItem.objects.create(order=order, product=item["product"], quantity=item["quantity"], price=item["unit_price"])
        request.session["smartmarket_cart"] = {}
        messages.success(request, "Замовлення оформлено. Статус можна відстежувати в кабінеті.")
        return redirect("market:order_success", pk=order.pk)
    context = {"form": form, "items": items, "total": total}
    context.update(_market_context(request))
    return render(request, "market/checkout.html", context)


def order_success(request, pk):
    context = {"order_id": pk}
    context.update(_market_context(request))
    return render(request, "market/order_success.html", context)


def business(request):
    form = WholesaleRequestForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Заявку на бізнес-акаунт прийнято. Менеджер зв'яжеться з вами.")
        return redirect("market:business")
    products = Product.objects.filter(is_active=True).select_related("category", "brand").order_by("-min_wholesale_quantity")[:6]
    context = {"form": form, "products": products}
    context.update(_market_context(request))
    return render(request, "market/business.html", context)


def dashboard(request):
    orders = request.user.market_orders.all()[:8] if request.user.is_authenticated else []
    items, total = _cart_items(request.session)
    wishlist_ids = _wishlist(request.session)
    viewed_ids = _viewed(request.session)
    wishlist_products = Product.objects.filter(id__in=wishlist_ids, is_active=True).select_related("category", "brand")
    viewed_products = Product.objects.filter(id__in=viewed_ids, is_active=True).select_related("category", "brand")
    context = {
        "orders": orders,
        "items": items,
        "total": total,
        "wishlist_products": wishlist_products,
        "viewed_products": viewed_products,
    }
    context.update(_market_context(request))
    return render(request, "market/dashboard.html", context)
