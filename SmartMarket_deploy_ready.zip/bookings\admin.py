from django.contrib import admin

from .models import Booking, Event


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ("title", "event_type", "starts_at", "capacity", "booked_seats", "available_seats", "is_active")
    list_filter = ("event_type", "is_active", "starts_at")
    search_fields = ("title", "description", "location")
    ordering = ("starts_at",)


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ("customer_name", "event", "seats", "status", "created_at")
    list_filter = ("status", "event")
    search_fields = ("customer_name", "customer_email", "customer_phone", "event__title")
    autocomplete_fields = ("event",)
